#
# AERA device configuration fragment for camellia.
# Templated from aera_garnet.mk / aera_giulia.mk (AERA-Recovery), values
# replaced with camellia facts from the PallzNtDv TWRP tree.
# This file is inherit-product'd from device.mk; it is not a lunch target.
#

AERA_MAINTAINER := hisvoice

# ----- Screen settings -----
# Camellia's panel is exactly 1080x2400, so the AERA reference-space
# height (1080 x panel_H / panel_W) equals the physical height: 2400.
AERA_SCREEN_H := 2400
AERA_STATUS_H := 115
# Starting values templated from giulia/garnet; UNVERIFIED against
# camellia's punch-hole position - tune on device.
AERA_STATUS_INDENT_LEFT := 40
AERA_STATUS_INDENT_RIGHT := 40
AERA_HIDE_NOTCH := 1
AERA_CLOCK_POS := 1
AERA_ALLOW_DISABLE_NAVBAR := 0
AERA_USE_GREEN_LED := 0

# number of list options before scrollbar creation
AERA_OPTIONS_LIST_NUM := 11

# ----- Other -----
AERA_QUICK_BACKUP_LIST := /boot;/data;
AERA_DYNAMIC_FULL_SIZE := 9126805504
AERA_ENABLE_LPTOOLS := 1
AERA_USE_DMCTL := 1
AERA_ENABLE_ALL_PARTITION_TOOLS := 1
AERA_NO_TREBLE_COMPATIBILITY_CHECK := 1

# Camellia ships a prebuilt kernel (the BoardConfig prebuilt block does
# the real work; this mirrors garnet's placement of the same flag).
AERA_FORCE_PREBUILT_KERNEL := 1

# ----- Data format hygiene -----
# userdata is f2fs
AERA_FORCE_DATA_FORMAT_F2FS := 1

# ensure that /sdcard is bind-unmounted before f2fs data repair or format
AERA_UNBIND_SDCARD_F2FS := 1

# automatically wipe /metadata after data format
AERA_WIPE_METADATA_AFTER_DATAFORMAT := 1

# avoid MTP issues after data format
AERA_BIND_MOUNT_SDCARD_ON_FORMAT := 1

# unmount emulated storage cleanly before rebooting or formatting
AERA_UNMOUNT_SDCARDS_BEFORE_REBOOT := 1

# don't spam the console with loop errors
AERA_LOOP_DEVICE_ERRORS_TO_LOG := 1

AERA_DISABLE_ORS_AUTO_REBOOT := 1
AERA_USE_LOCKSCREEN_BUTTON := 1

# Deliberately NOT set here (see PORT_BLUEPRINT.md SS2.5/SS4):
# AERA_FORCE_CASEFOLDING (camellia casefold status unrecorded),
# AERA_USE_LZ4_COMPRESSION, AERA_NO_RELOAD_AFTER_DECRYPTION,
# AERA_ENABLE_FRP_WIPE (out of scope by standing rule),
# AERA_AB_DEVICE_WITH_RECOVERY_PARTITION (no recovery partition),
# AERA_ENABLE_WLAN (off for v1 - no MTK connectivity stack in tree).

#
# Copyright (C) 2024 The Team Win Recovery Project
#
# SPDX-License-Identifier: Apache-2.0
#

PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/twrp_camellia.mk

COMMON_LUNCH_CHOICES := \
    twrp_camellia-bp2a-eng \
    twrp_camellia-bp2a-userdebug \
    twrp_camellia-bp2a-user \
    twrp_camellia-eng \
    twrp_camellia-userdebug \
    twrp_camellia-user

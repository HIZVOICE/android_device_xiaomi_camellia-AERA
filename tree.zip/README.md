## Xiaomi Redmi Note 10 5G (_camellia_) / Redmi Note 10T / POCO M3 Pro 5G
## AERA Recovery device tree (unofficial port)

> **Status: first-draft port. Nothing here has been built or booted yet.**
> This tree ports AERA Recovery to the first MediaTek device (every
> existing AERA device is Snapdragon). Everything in the "Works" list
> below is a target, not a result, until the first build is graded on a
> real phone.

## Device specifications

Device                  | Xiaomi Redmi Note 10 5G / camellian (global)
-----------------------:|:-----------------------------------------
SoC                     | MediaTek MT6833 Dimensity 700 (7 nm)
CPU                     | Octa-core (2x2.2 GHz Cortex-A76 & 6x2.0 GHz Cortex-A55)
GPU                     | Mali-G57 MC2
Memory                  | 4/6/8 GB RAM
Storage                 | 64/128/256 GB (UFS 2.2)
MicroSD                 | Yes
Shipped Android Version | 11.0 (MIUI 12)
Battery                 | Non-removable Li-Po 5000 mAh
Display                 | 1080 x 2400 pixels, 90 Hz, 6.5 inches (Novatek NT36672C/D or FocalTech touch)

Layout: virtual A/B, **no recovery partition** (recovery lives in
`boot`), no vendor_boot, boot image header v2. The build target is
therefore `bootimage`, not `recoveryimage`.

## Features

Works (to be graded on the first build, in this order):

- [ ] Display
- [ ] Touch (incl. after sleep/wake - the donor NVT watchdog is carried)
- [ ] ADB / Sideload
- [ ] **Decryption - UNPROVEN.** The full Microtrust TEE stack
      (teei_daemon, keymaster@4.1 beanpod, gatekeeper) is carried from
      the device's proven TWRP tree, but AERA's init has no
      `install_keyring` builtin (that line was removed from
      init.mt6833.rc) and nobody has run this TEE under AERA before.
      This is the port's open question #1.
- [ ] Flashing
- [ ] Fastbootd
- [ ] MTP
- [ ] USB OTG
- [ ] Backup / Restore

Known omissions (by design, stated plainly):

- **No SIM / mobile data in recovery.** AERA's mobile features ride
  Qualcomm modem services (QRTR/RMTFS) that do not exist on MediaTek.
  Not planned unless an MTK modem bring-up ever exists.
- **No Wi-Fi in recovery (v1).** The MTK connectivity stack (wmt +
  WLAN firmware from the vendor image) is not part of this tree.
  Networking-dependent AERA extras (cloud backup, SMB/SFTP, remote
  terminal) therefore only have USB/ADB as a transport.
- **Root Manager is OFF.** Its bundled modules are GKI/KMI builds for
  modern kernels; camellia's 4.14 non-GKI kernel can never load them.
- FRP wipe addon is not enabled.

## Building

Sync the AERA sources (`aera-16.0` branch of AERA-Recovery's
manifest), place this tree at `device/xiaomi/camellia`, then run:

```
source build/envsetup.sh
lunch twrp_camellia-bp2a-eng
mka adbd bootimage
```

Verify the resulting `boot.img` before flashing: size must be
<= 67,108,864 bytes, header v2 / page 2048, and the ramdisk must
contain the Microtrust payload and the NVT watchdog.

## Credits
- Device tree base: [PallzNtDv](https://github.com/PallzNtDv)'s TWRP tree for camellia (decryption stack, prebuilt kernel/DTB, fstabs)
- NVT touch wake watchdog: cristi (2026-05-22), donor variant via the fox_camellia OrangeFox build
- [AERA Recovery Project](https://github.com/AERA-Recovery)

### Copyright
 ```
  /*
  *  Copyright (C) 2024 The OrangeFox Recovery Project
  *
  * This program is free software: you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation, either version 3 of the License, or
  * (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  */
  ```

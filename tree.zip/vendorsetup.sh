#
# Copyright (C) 2023 The OrangeFox Recovery Project
#
# SPDX-License-Identifier: Apache-2.0
#
# AERA build environment for camellia.
# Templated from the garnet/giulia vendorsetup.sh (AERA-Recovery).
#

FDEVICE="camellia"

aera_get_target_device() {
	local script_path
	script_path="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
	if echo "$script_path" | grep -q "/$FDEVICE$"; then
		AERA_BUILD_DEVICE="$FDEVICE"
	elif echo "$0" | grep -q "$FDEVICE"; then
		AERA_BUILD_DEVICE="$FDEVICE"
	fi
}

if [ -z "$AERA_BUILD_DEVICE" ]; then
	aera_get_target_device
fi

if [ "$1" = "$FDEVICE" ] || [ "$AERA_BUILD_DEVICE" = "$FDEVICE" ]; then
	export LC_ALL="C"
	export AERA_AB_DEVICE=1
	export AERA_VIRTUAL_AB_DEVICE=1
	export AERA_VANILLA_BUILD=1
	export AERA_PRODUCT_PREFIX=AERA
	# Unofficial: this tree is not part of the AERA project.
	export AERA_BUILD_STATUS=Unofficial
	export AERA_BUILD_TYPE=Beta
	export AERA_RECOVERY_SYSTEM_PARTITION="/dev/block/mapper/system"
	export AERA_RECOVERY_VENDOR_PARTITION="/dev/block/mapper/vendor"

	export AERA_USE_BASH_SHELL=1
	export AERA_USE_TAR_BINARY=1
	export AERA_USE_SED_BINARY=1
	export AERA_USE_LZ4_BINARY=1
	export AERA_USE_ZSTD_BINARY=1
	export AERA_USE_DATE_BINARY=1
	export AERA_USE_GREP_BINARY=1
	export AERA_USE_BUSYBOX_BINARY=1
	export AERA_USE_XZ_UTILS=1
	export AERA_USE_NANO_EDITOR=1
	export AERA_DELETE_AROMAFM=1
	export AERA_DELETE_MAGISK_ADDON=1
	export AERA_USE_UPDATED_MAGISKBOOT=1
	export AERA_USE_FSCK_EROFS_BINARY=1
	export AERA_USE_PATCHELF_BINARY=1

	export AERA_SETTINGS_ROOT_DIRECTORY=/data/recovery
	export AERA_MISCELLANEOUS_ROOT_DIRECTORY=/sdcard
	export AERA_ALLOW_EARLY_SETTINGS_LOAD=1

	# TODO(risk #9, OPEN): append the stock hardware model IDs
	# (ro.product.model values from stock camellia / camellian
	# build.props, e.g. the M2103K19xx family) to this list before
	# the first release build, or OTA asserts may reject ROM zips
	# that check model IDs. The IDs were NOT present in any local
	# evidence at draft time (the A1 sample / donor prop.default
	# files carry the recovery's own model string, not stock), so
	# they are deliberately left as this placeholder instead of
	# being invented. See DRAFT_NOTES.md.
	export TARGET_DEVICE_ALT="camellia,camellian"
	export AERA_TARGET_DEVICES="$TARGET_DEVICE_ALT"

	# AERA_ENABLE_ROOT_MANAGER is deliberately NOT exported:
	# camellia's 4.14 non-GKI kernel has no KMI, so no bundled
	# root-provider module catalog can ever match it (blueprint SS3.4).

	# AERA begins at R1.0; do not append legacy variant or patch suffixes.
	unset AERA_VARIANT
	unset AERA_MAINTAINER_PATCH_VERSION
fi

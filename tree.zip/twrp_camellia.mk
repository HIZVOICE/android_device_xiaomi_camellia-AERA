#
# Copyright (C) 2023 The OrangeFox Recovery Project
#
# SPDX-License-Identifier: Apache-2.0
#

# Inherit from those products. Most specific first.
$(call inherit-product, $(SRC_TARGET_DIR)/product/aosp_base.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)

# Inherit from our custom product configuration
$(call inherit-product, vendor/twrp/config/common.mk)

# Device path — MUST be set here, before device.mk is inherited.
# device.mk uses $(DEVICE_PATH) for the aera_camellia.mk inherit and for
# PRODUCT_SOONG_NAMESPACES, and BoardConfig.mk (which also defines it) is
# only loaded AFTER product parsing, so at device.mk time it expands empty
# and the build dies with "/aera_camellia.mk does not exist" (AERA build #4,
# run 42324022764). Garnet defines it in twrp_garnet.mk the same way.
DEVICE_PATH := device/xiaomi/camellia

# Inherit from everpal device
$(call inherit-product, device/xiaomi/camellia/device.mk)

# Device identifier. This must come after all inclusions
PRODUCT_DEVICE := camellia
PRODUCT_NAME := twrp_camellia
PRODUCT_BRAND := xiaomi
PRODUCT_MANUFACTURER := xiaomi

PRODUCT_GMS_CLIENTID_BASE := android-xiaomi

PRODUCT_BUILD_PROP_OVERRIDES += \
    PRIVATE_BUILD_DESC="camellia-user 12 SP1A.210812.016 V14.0.6.0.TKSIDXM release-keys"

BUILD_FINGERPRINT := Redmi/camellia/camellia:12/SP1A.210812.016/V14.0.6.0.TKSIDXM:user/release-keys
